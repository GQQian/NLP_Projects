README.txt

install textblob:

$ pip install -U textblob
$ python -m textblob.download_corpora

textblob uses NLTK, which will be automatically install 
as you install textblob

To run the baseline model, run baseline.py, the program
will write the results to answer.txt in the same folder.
