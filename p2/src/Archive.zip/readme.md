CS 4740 Project 2: Uncertainty Detection
Group Name: anonymous2.33
Group member: Zili Xiang(zx77), Youdan Xu(yx339), Guanqiao Qian(gq25)
########################################################################
##### More specific about what we implemented for this project, ########
####################### READ proposal.pdf ##############################
########################################################################
Baseline Model:
We used online dictionary of hedge words for uncertainty hedges as our baseline model. The reference and details, please see comments in bm_model.py

1. Test functions are all in test.py, to know about what specifically what each function intends to do, read description of that function. 
 (additionally, crf model should be tested directly on crf_model.py)
2. Test functions in test.py are to be executed in main.py, we have marked the location where you should put functions from test.py.

3. The results of uncertain_sent_detection function will be in sentence_result.csv and uncertain_phrase_detection function will be in phrase_result.csv.

4. Have fun grading!
