# TODO: 1. read files, parse files
#       2. feeding data to models
#       3. getting predictions from models and write to files
from test import *


def main():
#############################################################################################
#############################################################################################
##### replace the function below with whatever function you want to call from test.py #######
#############################################################################################
#############################################################################################
    uncertain_sent_detection()

if __name__ == "__main__":
    main()